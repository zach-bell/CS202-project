package com.vexoid.game.screen;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GameOverScreen extends Screen{

	public void create(String difficulty) {
		
	}

	public void update() {
		
	}

	public void render(SpriteBatch sb) {
		
	}

	public void resize(int width, int height) {
		
	}

	public void dispose() {
		
	}

	public void pause() {
		
	}

	public void resume() {
		
	}

	public String whatScreen() {
		return "GameOver";
	}

}
