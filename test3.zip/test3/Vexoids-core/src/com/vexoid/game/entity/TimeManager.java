package com.vexoid.game.entity;

import com.vexoid.game.camera.OrthoCamera;

public class TimeManager extends EntityManager{

	public TimeManager(int amount, OrthoCamera camera, String difficulty) {
		super(amount, camera, difficulty);
	}
	public void update(){
		
	}
}
